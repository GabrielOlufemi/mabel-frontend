/**
 * nav.js — Shared navigation component for Mabel
 * Set window.NAV_ACTIVE before loading this script.
 * Values: 'chat' | 'summarize' | 'flashcards' | 'quiz'
 */
(function () {
  var active = window.NAV_ACTIVE || 'chat';

  var pages = [
    { id: 'chat',       label: 'Chat',       href: 'index.html',      icon: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>' },
    { id: 'summarize',  label: 'Summarize',  href: 'summarize.html',  icon: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3" cy="6" r="1"/><circle cx="3" cy="12" r="1"/><circle cx="3" cy="18" r="1"/>' },
    { id: 'flashcards', label: 'Flashcards', href: 'flashcards.html', icon: '<rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/>' },
    { id: 'quiz',       label: 'Quiz',       href: 'quiz.html',       icon: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>' },
  ];

  function svgIcon(inner, size) {
    size = size || 14;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + inner + '</svg>';
  }

  var navItems = pages.map(function(p) {
    return '<a class="sidebar-item' + (p.id === active ? ' active' : '') + '" href="' + p.href + '">' +
      svgIcon(p.icon) +
      '<span class="nav-text">' + p.label + '</span>' +
      '</a>';
  }).join('');

  function updateArrow() {
    var iconEl = document.getElementById('sidebar-arrow-icon');
    if (!iconEl) return;
    var collapsed = document.getElementById('sidebar').classList.contains('collapsed');
    iconEl.innerHTML = collapsed
      ? '<polyline points="9 18 15 12 9 6"/>'
      : '<polyline points="15 18 9 12 15 6"/>';
    // Only set inline left on desktop — on mobile CSS !important handles it
    // and inline styles would override the media query
    if (window.innerWidth > 768) {
      var nav = document.querySelector('.nav');
      if (nav) nav.style.left = (collapsed ? '56px' : '220px');
    }
  }

  // Clear inline style on resize so desktop<->mobile switching is clean
  window.addEventListener('resize', function() {
    var nav = document.querySelector('.nav');
    if (!nav) return;
    if (window.innerWidth <= 768) {
      nav.style.left = '';
    } else {
      var collapsed = document.getElementById('sidebar').classList.contains('collapsed');
      nav.style.left = collapsed ? '56px' : '220px';
    }
  });

  window.MabelNav = {
    toggleTheme: function() {
      document.body.classList.toggle('dark');
      localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
    },
    toggleCollapse: function() {
      document.getElementById('sidebar').classList.toggle('collapsed');
      var collapsed = document.getElementById('sidebar').classList.contains('collapsed');
      localStorage.setItem('sidebar-collapsed', collapsed ? '1' : '0');
      updateArrow();
    },
    open: function() {
      document.getElementById('sidebar').classList.add('open');
      document.getElementById('sidebar-backdrop').classList.add('visible');
      // Hide the hamburger trigger while sidebar is open
      document.getElementById('sidebar-trigger').classList.add('hidden');
      // On mobile, shift the nav right so it doesn't sit under the sidebar
      var nav = document.querySelector('.nav');
      if (nav) nav.classList.add('sidebar-open');
    },
    close: function() {
      document.getElementById('sidebar').classList.remove('open');
      document.getElementById('sidebar-backdrop').classList.remove('visible');
      document.getElementById('sidebar-trigger').classList.remove('hidden');
      // Restore nav position
      var nav = document.querySelector('.nav');
      if (nav) nav.classList.remove('sidebar-open');
    }
  };

  // Backwards-compat aliases
  window.toggleTheme           = window.MabelNav.toggleTheme;
  window.toggleSidebarCollapse = window.MabelNav.toggleCollapse;
  window.toggleSidebar         = window.MabelNav.open;
  window.closeSidebar          = window.MabelNav.close;

  function inject() {
    // Apply saved theme
    if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark');

    var sidebarHTML = [
      '<aside class="sidebar" id="sidebar">',
        '<div class="sidebar-brand">',
          '<span class="nav-text sidebar-brand-name">Mabel</span>',
          '<span class="nav-text nav-badge" style="margin-left:2px">beta</span>',
          '<button class="sidebar-arrow-btn" id="sidebar-arrow-btn" onclick="MabelNav.toggleCollapse()" title="Toggle sidebar">',
            '<svg id="sidebar-arrow-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">',
              '<polyline points="15 18 9 12 15 6"/>',
            '</svg>',
          '</button>',
        '</div>',
        '<div class="sidebar-scroll">',
          '<div class="sidebar-label-row" style="display:flex;align-items:center;padding:10px 4px 4px">',
            '<span class="label-text" style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--text-3)">Workspace</span>',
          '</div>',
          navItems,
          '<div class="sidebar-sep"></div>',
          '<div class="sidebar-label">History</div>',
          '<div class="sidebar-item sidebar-item--muted">',
            '<span class="nav-text" style="color:var(--text-3);font-style:italic;font-size:12px">No sessions yet</span>',
          '</div>',
        '</div>',
        '<div class="sidebar-footer">',
          '<a class="user-row" href="settings.html">',
            '<div class="avatar">J</div>',
            '<div class="user-info">',
              '<div class="user-name">Jamie Lee</div>',
              '<div class="user-plan">',
                '<svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
                'Pro Plan',
              '</div>',
            '</div>',
            '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--text-3)"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>',
          '</a>',
        '</div>',
      '</aside>',
    ].join('');

    var overlayHTML = [
      '<div class="sidebar-backdrop" id="sidebar-backdrop" onclick="MabelNav.close()"></div>',
      // Hamburger trigger — z-index raised above nav so it's always clickable
      '<button class="sidebar-trigger" id="sidebar-trigger" onclick="MabelNav.open()" aria-label="Open menu">',
        '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">',
          '<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>',
        '</svg>',
      '</button>',
      '<nav class="nav" id="mabel-nav">',
        '<div class="nav-right">',
          '<a class="nav-btn hide-mobile" href="#">Docs</a>',
          '<a class="nav-btn hide-mobile" href="#" target="_blank">',
            '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>',
            'GitHub',
          '</a>',
          '<button class="theme-trigger" onclick="MabelNav.toggleTheme()" title="Toggle dark mode">',
            '<svg class="icon-moon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
            '<svg class="icon-sun" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
          '</button>',
          '<a class="nav-btn primary" href="#">Demo</a>',
        '</div>',
      '</nav>',
    ].join('');

    // Sidebar MUST be first child of .layout so the flex row is: [sidebar][main]
    var layout = document.querySelector('.layout');
    if (layout) {
      layout.insertAdjacentHTML('afterbegin', sidebarHTML);
    } else {
      document.body.insertAdjacentHTML('afterbegin', sidebarHTML);
    }

    // Fixed-position overlays go on body
    document.body.insertAdjacentHTML('afterbegin', overlayHTML);

    // Restore sidebar collapsed state
    if (localStorage.getItem('sidebar-collapsed') === '1') {
      document.getElementById('sidebar').classList.add('collapsed');
    }
    updateArrow();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inject);
  } else {
    inject();
  }
})();